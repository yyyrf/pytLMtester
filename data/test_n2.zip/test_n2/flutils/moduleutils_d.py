import importlib
import keyword
import sys
from collections import defaultdict
from importlib import util
from importlib.abc import Loader
from importlib.machinery import ModuleSpec
from types import ModuleType
from typing import (
    Any,
    DefaultDict,
    Dict,
    Generator,
    List,
    NamedTuple,
    Optional,
    Set,
    Tuple,
    Union,
    cast,
)

__all__ = ['cherry_pick', 'lazy_import_module']

# ... rest of the code ...

def _validate_attr_identifier(identifier: str, line: str) -> str:
    # ... function body ...

class _AttrMapping(NamedTuple):
    # ... class body ...

def _expand_attr_map_item(foreign_name: str) -> _AttrMapping:
    # ... function body ...

def _expand_attr_map(attr_map: Tuple[str, ...]) -> Generator[_AttrMapping, None, None]:
    # ... function body ...

class _CherryPickMap(NamedTuple):
    # ... class body ...

class CherryPickError(ImportError):
    # ... class body ...

def _parse_attr_map(attr_map: Tuple[str, ...], fullname: str) -> _CherryPickMap:
    # ... function body ...

class _CherryPickingModule(ModuleType):
    # ... class body ...

class _CherryPickingLoader(Loader):
    # ... class body ...

class _CherryPickFinder:
    # ... class body ...

def cherry_pick(namespace: Dict[str, Any]) -> None:
    # ... function body ...

class _LazyModule(ModuleType):
    # ... class body ...

class _LazyLoader(Loader):
    # ... class body ...

def lazy_import_module(name: str, package: Optional[str] = None) -> ModuleType:
    # ... function body ...