"""
HTTPie: command-line HTTP client for the API era.

"""

__version__ = '2.4.0'
__author__ = 'Jakub Roztocil'
__licence__ = 'BSD'
