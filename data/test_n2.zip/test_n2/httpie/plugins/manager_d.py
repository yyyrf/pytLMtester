from itertools import groupby
from operator import attrgetter
from typing import Dict, List, Type, Any

from pkg_resources import iter_entry_points

from httpie.plugins import AuthPlugin, ConverterPlugin, FormatterPlugin
from httpie.plugins.base import BasePlugin, TransportPlugin


ENTRY_POINT_NAMES = [
    'httpie.plugins.auth.v1',
    'httpie.plugins.formatter.v1',
    'httpie.plugins.converter.v1',
    'httpie.plugins.transport.v1',
]


class PluginManager(list):

    def register(self, *plugins: BasePlugin) -> None:
        for plugin in plugins:
            self.append(plugin)

    def unregister(self, plugin: BasePlugin) -> None:
        self.remove(plugin)

    def filter(self, by_type: Type[BasePlugin]) -> List[BasePlugin]:
        return [plugin for plugin in self if issubclass(plugin, by_type)]

    def load_installed_plugins(self) -> None:
        for entry_point_name in ENTRY_POINT_NAMES:
            for entry_point in iter_entry_points(entry_point_name):
                plugin = entry_point.load()
                plugin.package_name = entry_point.dist.key
                self.register(entry_point.load())

    # Auth
    def get_auth_plugins(self) -> List[AuthPlugin]:
        return self.filter(AuthPlugin)

    def get_auth_plugin_mapping(self) -> Dict[str, AuthPlugin]:
        return {
            plugin.auth_type: plugin for plugin in self.get_auth_plugins()
        }

    def get_auth_plugin(self, auth_type: str) -> AuthPlugin:
        return self.get_auth_plugin_mapping()[auth_type]

    # Output processing
    def get_formatters(self) -> List[FormatterPlugin]:
        return self.filter(FormatterPlugin)

    def get_formatters_grouped(self) -> Dict[str, List[FormatterPlugin]]:
        return {
            group_name: list(group)
            for group_name, group
            in groupby(self.get_formatters(), key=attrgetter('group_name'))
        }

    def get_converters(self) -> List[ConverterPlugin]:
        return self.filter(ConverterPlugin)

    # Adapters
    def get_transport_plugins(self) -> List[TransportPlugin]:
        return self.filter(TransportPlugin)

    def __repr__(self) -> str:
        return f'<PluginManager: {list(self)}>'