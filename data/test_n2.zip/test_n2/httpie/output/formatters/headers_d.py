from httpie.plugins import FormatterPlugin
from typing import List, Dict, Any, Optional

class HeadersFormatter(FormatterPlugin):

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.enabled: bool = self.format_options['headers']['sort']

    def format_headers(self, headers: str) -> str:
        """
        Sorts headers by name while retaining relative
        order of multiple headers with the same name.
        """
        lines: List[str] = headers.splitlines()
        headers_sorted: List[str] = sorted(lines[1:], key=lambda h: h.split(':')[0])
        return '\r\n'.join(lines[:1] + headers_sorted)