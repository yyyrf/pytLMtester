from typing import Set, Callable, Tuple, List, Any

from sanic.models.futures import FutureException


class ExceptionMixin:
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._future_exceptions: Set[FutureException] = set()

    def _apply_exception_handler(self, handler: Callable) -> None:
        raise NotImplementedError  # noqa

    def exception(self, *exceptions: Tuple[Exception, ...], apply: bool = True) -> Callable[[Callable], Callable]:
        """
        This method enables the process of creating a global exception
        handler for the current blueprint under question.

        :param exceptions: List of Python exceptions to be caught by the handler
        :param apply: Additional optional arguments to be passed to the
            exception handler

        :return a decorated method to handle global exceptions for any
            route registered under this blueprint.
        """

        def decorator(handler: Callable) -> Callable:
            nonlocal apply
            nonlocal exceptions

            if isinstance(exceptions[0], list):
                exceptions = tuple(*exceptions)

            future_exception = FutureException(handler, exceptions)
            self._future_exceptions.add(future_exception)
            if apply:
                self._apply_exception_handler(future_exception)
            return handler

        return decorator